<?php

namespace App\Filament\Resources\AdvResource\Pages;

use App\Filament\Resources\AdvResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAdv extends CreateRecord
{
    protected static string $resource = AdvResource::class;
}
