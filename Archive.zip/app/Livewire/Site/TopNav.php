<?php

namespace App\Livewire\Site;

use Livewire\Component;

class TopNav extends Component
{
    public function render()
    {
        return view('livewire.site.top-nav');
    }
}
