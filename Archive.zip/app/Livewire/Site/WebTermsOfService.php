<?php

namespace App\Livewire\Site;

use Livewire\Component;

class WebTermsOfService extends Component
{
    public function render()
    {
        return view('livewire.site.web-terms-of-service');
    }
}
